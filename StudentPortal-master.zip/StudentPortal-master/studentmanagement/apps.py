from django.apps import AppConfig


class StudentmanagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'studentmanagement'

    def ready(self):
        import studentmanagement.signals
