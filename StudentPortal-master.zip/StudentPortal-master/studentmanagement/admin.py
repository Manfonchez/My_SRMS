from django.contrib import admin
from studentmanagement.models import *
# Register your models here.

admin.site.register(Student)
admin.site.register(Contact)
