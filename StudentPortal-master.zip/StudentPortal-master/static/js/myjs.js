$(document).ready(function () {
		 $('.table').paging({limit:15});

        });